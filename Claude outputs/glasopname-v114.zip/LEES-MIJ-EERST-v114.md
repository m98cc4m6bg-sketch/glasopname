# Glasopname v114: plaatsen

Wat er nieuw is, staat in `WIJZIGINGEN-v114.md` in de **andere** zip
(`glasopname-v114-niet-in-repo.zip`). In het kort:
- **latzijde per ruit** (binnen / buiten / beide), zonder standaard: een
  nieuwe ruit staat op "?" en de app vraagt erom;
- **diepte onderdorpel**, het oordeel over de hele ruit, **advies
  aantikken**;
- **het merk blijft in beeld** bij zijwaarts vegen;
- **Toebehoren op de telefoon** ingeklapt (één regel per ruit);
- na een bestelling gaan de **latkeuzes mee op slot**;
- **bi-color rooster** (RAL buiten / RAL binnen);
- alleen het rooster anders na een bestelling: blok **ALLEEN ROOSTER**;
- een **vaste zin** bovenaan elke aanvulling;
- **latmaten volgens Jongeneel**, met foto's en tekeningen; het fotoscript
  is weg.

Er zijn **twee zips**:
- `glasopname-v114.zip` (deze): precies wat in de repo hoort.
- `glasopname-v114-niet-in-repo.zip`: bewust **niet** in de repo (nota,
  handover, oude nota's). Bewaar die op een eigen plek, bijvoorbeeld
  OneDrive. Zet hem niet in de repomap.

## 1. SQL

Geen.

## 2. Eerst weggooien (in de repomap)

- `latfotos-ophalen.sh` (het script; Jongeneel blokkeert scripts)
- `latten/GL13.jpg` (die lat heet nu B13; `latten/B13.jpg` zit in de zip)

## 3. De bestanden

1. Open de map `glasopname` in deze zip.
2. Druk **Cmd+Shift+.** om de verborgen bestanden te zien.
3. Selecteer alles en sleep het naar je repomap.
4. Kies **Vervang**.

## 4. In GitHub Desktop horen precies deze te staan

Nieuw (groen):
- `test-v114.js`
- in `latten/`: de 23 tekeningen (`A4-tek.jpg` … `N55-tek.jpg`) en
  `B13.jpg` (dezelfde foto als GL13; GitHub Desktop toont dat misschien als
  hernoemd). De 27 andere foto's zijn precies die van jouw commit "Latten":
  die horen **niet** in de lijst te staan.

Gewijzigd (geel):
- `index.html`, `latten.js`, `toebehoren.js`, `pdf.js`, `bulk.js`,
  `undo.js`, `sw.js`, `latfotos.txt`
- `test-v104.js`, `test-v105.js`, `test-v111.js`, `test-v112.js`,
  `test-v113.js`
- `BEHEER.md`, `OVERZICHT.md`, `DATAMODEL.md`, `STATUS.md`, `CLAUDE.md`,
  `TESTEN.md`, `GLASLATTEN.md`

Weg (rood):
- `latfotos-ophalen.sh`
- `latten/GL13.jpg`

Staat er meer of minder: niet pushen, even melden. Klopt het: commit en
push, en zeg het even, dan kijk ik de repo na.

## 5. Daarna

- **Alle apparaten even bijwerken** (↻ Bijwerken).
- **Proberen**: "Hoe je het zelf controleert" in `WIJZIGINGEN-v114.md`.
- **De vier vragen** onderaan die nota.
- **Nog open**: de Site URL in Supabase en de wachtwoordproef in Safari
  (zeg het als die gedaan zijn).
